@artifact.package@

import spock.lang.*

/**
 *
 */
class @artifact.name@ extends Specification {

    def setup() {
    }

    def cleanup() {
    }

    void "test something"() {
    }
}