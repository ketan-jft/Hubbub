package com.grailsinaction

class Profile {
    User user
    byte[] photo
    String fullName
    String bio
    String homepage
    String email
    String timezone
    String country
    String jabberAddress
    static belongsTo = [ user : User ]
}
